/*********************************************************************************
* WEB322 – Assignment 02
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: Sharan Shanmugaratnam Student ID: 153601174 Date: October 2 2018
*
* Online (Heroku) Link: https://peaceful-beyond-85370.herokuapp.com/
*
********************************************************************************/ 

var express = require("express");
var path = require("path");
var dataServ = require("./data-service.js");
var app = express();

app.use(express.static('public/css'));

var HTTP_PORT = process.env.PORT || 8080;

// call this function after the http server starts listening for requests
function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);
}

// setup a 'route' to listen on the default url path (http://localhost)
app.get("/", function (req, res) {
    res.sendFile(path.join(__dirname, "/views/home.html"));
});

app.get("/about", function (req, res) {
    res.sendFile(path.join(__dirname, "/views/about.html"));
});

app.get("/employees", function (req, res) {
    dataServ.getAllEmployees().then((data) => {
        res.json(data);
    }).catch((err) => {
        res.json(err);
    })
});

app.get("/managers", function (req, res) {
    dataServ.getManagers().then((data) => {
        res.json(data);
    }).catch((err) => {
        res.json(err);
    })
});

app.get("/departments", function (req, res) {
    dataServ.getDepartments().then((data) => {
        res.json(data);
    }).catch((err) => {
        res.json(err);
    })
});

dataServ.initialize().then(() => {
    // setup http server to listen on HTTP_PORT
    app.listen(HTTP_PORT, onHttpStart);
})
    .catch(err => {
        console.log("Error: " + err);
    })

app.use(function (res, req) {
    res.status(404).send("Page Not Found");
});