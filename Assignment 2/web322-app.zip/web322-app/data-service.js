var employees = [];
var departments = [];

const fs = require("fs");

module.exports.initialize = function () {
    var promise = new Promise((resolve, reject) => {
        try {
            fs.readFile('./data/employees.json', 'utf-8', (err, data) => {
                if (err) throw err;
                employees = JSON.parse(data);
            })

            fs.readFile('./data/departments.json', 'utf-8', (err, data) => {
                if (err) throw err;
                departments = JSON.parse(data);
            })
        }
        catch (ex) {
            reject("Unable to read file.")
        }
        resolve("Success!")
    })

    return promise;
};

module.exports.getAllEmployees = function () {
    var promise = new Promise((resolve, reject) => {
        if (employees.length == 0) {
            reject("No results returned.");
        }
        resolve(employees);
    })

    return promise;
};

module.exports.getManagers = function () {
    var promise = new Promise((resolve, reject) => {
        let managers = [];
        for (let i = 0; i < employees.length; i++) {
            if (employees[i].isManager == true) {
                managers.push(employees[i]);
            }
        }

        if (managers.length == 0) {
            reject("No results returned.");
        }
        resolve(managers);
    })

    return promise;
};

module.exports.getDepartments = function () {
    var promise = new Promise((resolve, reject) => {
        if (departments.length == 0) {
            reject("No results returned.");
        }
        resolve(departments);
    })

    return promise;
};