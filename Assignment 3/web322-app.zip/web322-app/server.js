/*********************************************************************************
* WEB322 – Assignment 02
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: Sharan Shanmugaratnam Student ID: 153601174 Date: October 10 2018
*
* Online (Heroku) Link: https://young-peak-80129.herokuapp.com/
*
********************************************************************************/

var express = require("express");
var path = require("path");
var dataServ = require("./data-service.js");
var app = express();
var multer = require("multer");
const fs = require("fs");
var bodyParser = require('body-parser');

app.use(express.static('public/css'));
app.use(bodyParser.urlencoded({ extended: true }));

var HTTP_PORT = process.env.PORT || 8080;

// call this function after the http server starts listening for requests
function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);
}

// multer requires a few options to be setup to store files with file extensions
// by default it won't store extensions for security reasons
const storage = multer.diskStorage({
    destination: "./public/images/uploaded",
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

// tell multer to use the diskStorage function for naming files instead of the default.
const upload = multer({ storage: storage });

// Adding the "Post" route.
app.post("/images/add", upload.single("imageFile"), (req, res) => {
    res.send("/images");
});

// Adding "Get" route / using the "fs" module
app.get("/images", function (req, res) {
    let filePath = path.join(__dirname, "/public/images/uploaded");
    fs.readdir(filePath, function (err, items) {
        res.json(items);
    })
});

// Adding "Post" route.
app.post("/employees/add", (req, res) => {
    console.log(req.body);
    dataServ.addEmployee(req.body)
        .then(res.redirect("/employees"))
        .catch((err) => console.log(err));
});


// setup a 'route' to listen on the default url path (http://localhost)
app.get("/", function (req, res) {
    res.sendFile(path.join(__dirname, "/views/home.html"));
});

app.get("/about", function (req, res) {
    res.sendFile(path.join(__dirname, "/views/about.html"));
});

app.get("/employees/add", function (req, res) {
    res.sendFile(path.join(__dirname, "/views/addEmployee.html"));
});

app.get("/images/add", function (req, res) {
    res.sendFile(path.join(__dirname, "/views/addImage.html"));
});

app.get("/employees", function (req, res) {
    if (req.query.status) {
        dataServ.getEmployeesByStatus(req.query.status).then((data) => {
            res.json(data);
        }).catch((err)=>{
            res.send("Oops! "+ err);
        });
    }
    else if (req.query.department) {
        dataServ.getEmployeesByDepartment(req.query.department).then((data) => {
            res.json(data);
        }).catch((err)=>{
            res.send("Oops! "+ err);
        });
    }
    else if (req.query.manager) {
        dataServ.getEmployeesByManager(req.query.manager).then((data) => {
            res.json(data);
        }).catch((err)=>{
            res.send("Oops! "+ err);
        });
    }
    else {
        dataServ.getAllEmployees().then((data) => {
            res.json(data);
        }).catch((err) => {
            res.json(err);
        });
    }
});

app.get("/managers", function (req, res) {
    dataServ.getManagers().then((data) => {
        res.json(data);
    }).catch((err) => {
        res.json(err);
    });
});

app.get("/employee/:value", (req, res) => {
    dataServ.getEmployeeByNum(req.params.value).then((data) => {
        res.json(data);
    }).catch((err) => {
        res.json(err);
    });
});

app.get("/departments", function (req, res) {
    dataServ.getDepartments().then((data) => {
        res.json(data);
    }).catch((err) => {
        res.json(err);
    })
});

dataServ.initialize().then(() => {
    // setup http server to listen on HTTP_PORT
    app.listen(HTTP_PORT, onHttpStart);
})
    .catch(err => {
        console.log("Error: " + err);
    })

app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname,"/views/lost.html"));
});