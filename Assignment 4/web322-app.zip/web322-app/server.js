/*********************************************************************************
* WEB322 – Assignment 04
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: Sharan Shanmugaratnam Student ID: 153601174 Date: October 31 2018
*
* Online (Heroku) Link: https://young-peak-80129.herokuapp.com/
*
********************************************************************************/

var express = require("express");
var path = require("path");
var dataServ = require("./data-service.js");
var app = express();
var multer = require("multer");
const fs = require("fs");
var bodyParser = require('body-parser');
const exphbs = require('express-handlebars');

app.engine('.hbs', exphbs({
    extname: '.hbs',
    defaultLayout: 'main',
    helpers: {
        navLink: function (url, options) {
            return '<li' +
                ((url == app.locals.activeRoute) ? ' class="active" ' : '') +
                '><a href="' + url + '">' + options.fn(this) + '</a></li>';
        },
        equal: function (lvalue, rvalue, options) {
            if (arguments.length < 3)
                throw new Error("Handlebars Helper equal needs 2 parameters");
            if (lvalue != rvalue) {
                return options.inverse(this);
            } else {
                return options.fn(this);
            }
        }
    }
}));
app.set('view engine', '.hbs');

app.use(express.static('public/'));
app.use(bodyParser.urlencoded({ extended: true }));

var HTTP_PORT = process.env.PORT || 8080;

// call this function after the http server starts listening for requests
function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);
}

// multer requires a few options to be setup to store files with file extensions
// by default it won't store extensions for security reasons
const storage = multer.diskStorage({
    destination: "./public/images/uploaded",
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

// tell multer to use the diskStorage function for naming files instead of the default.
const upload = multer({ storage: storage });

// This will add the property "activeRoute" to "app.locals" whenever the route changes, ie: if our route is
// "/employees/add", the app.locals.activeRoute value will be "/employees/add".
app.use(function (req, res, next) {
    let route = req.baseUrl + req.path;
    app.locals.activeRoute = (route == "/") ? "/" : route.replace(/\/$/, "");
    next();
});

// Adding "Get" route / using the "fs" module
app.get("/images", function(req,res){
    fs.readdir(__dirname + "/public/images/uploaded", (err, image)=>{
    res.render("images", {data: image}); 
    });
});

// Adding the "Post" route.
app.post("/images/add", upload.single("imageFile"), (req, res) => {
    res.redirect("/images");
});

// Adding "Post" route.
app.post("/employees/add", (req, res) => {
    console.log(req.body);
    dataServ.addEmployee(req.body)
        .then(res.redirect("/employees"))
        .catch((err) => console.log(err));
});


// setup a 'route' to listen on the default url path (http://localhost)
app.get("/", function (req, res) {
    res.render("home");
});

app.get("/about", function (req, res) {
    res.render("about");
});

app.get("/employees/add", function (req, res) {
    res.render("addEmployee");
});

app.get("/images/add", function (req, res) {
    res.render("addImage");
});

app.get("/employees", function (req, res) {
    if (req.query.status) {
        dataServ.getEmployeesByStatus(req.query.status).then((data) => {
            res.render('employees', {employees: data});
        }).catch((err) => {
            res.render('employees', {message: "no results"});
        });
    }
    else if (req.query.department) {
        dataServ.getEmployeesByDepartment(req.query.department).then((data) => {
            res.render('employees', {employees: data});
        }).catch((err) => {
            res.render('employees', {message: "no results"});
        });
    }
    else if (req.query.manager) {
        dataServ.getEmployeesByManager(req.query.manager).then((data) => {
            res.render('employees', {employees: data});
        }).catch((err) => {
            res.render('employees', {message: "no results"});
        });
    }
    else {
        dataServ.getAllEmployees().then((data) => {
            res.render('employees', {employees: data});
        }).catch((err) => {
            res.render('employees', {message: "no results"});
        });
    }
});

app.get("/employee/:value", (req, res) => {
    dataServ.getEmployeeByNum(req.params.value).then((data) => {
        res.render('employee', {employee: data});
    }).catch((err) => {
        res.render("employee", {message: "no results"});
    });
});

app.get("/departments", function (req, res) {
    dataServ.getDepartments().then((data) => {
        res.render('departments', {departments: data});
    }).catch((err) => {
        res.send(err);
    })
});

app.post("/employee/update", (req, res) => {
    dataServ.updateEmployee(req.body).then(() => {
        res.redirect("/employees");
    }).catch((err) => {
        res.send(err);
    })
});

dataServ.initialize().then(() => {
    // setup http server to listen on HTTP_PORT
    app.listen(HTTP_PORT, onHttpStart);
})
    .catch(err => {
        console.log("Error: " + err);
    })

app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, "/views/lost.html"));
});