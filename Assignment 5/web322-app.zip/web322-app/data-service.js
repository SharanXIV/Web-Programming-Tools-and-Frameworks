const Sequelize = require('sequelize');

var sequelize = new Sequelize('d2or036fq3rr1e', 'bpijhurealydaf', 'fbfbb887763cbe6185795edc2dbc2c21f2778ee2347e1f04cab24a5127938f3e', {
    host: 'ec2-54-163-230-178.compute-1.amazonaws.com',
    dialect: 'postgres',
    port: 5432,
    dialectOptions: {
        ssl: true
    }
});

var Employee = sequelize.define('Employee', {
    employeeNum: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    email: Sequelize.STRING,
    SSN: Sequelize.STRING,
    addressStreet: Sequelize.STRING,
    addressCity: Sequelize.STRING,
    addressState: Sequelize.STRING,
    addressPostal: Sequelize.STRING,
    maritalStatus: Sequelize.STRING,
    isManager: Sequelize.BOOLEAN,
    employeeManagerNum: Sequelize.INTEGER,
    status: Sequelize.STRING,
    hireDate: Sequelize.STRING,
    department: Sequelize.INTEGER
});

var Department = sequelize.define('Department', {
    departmentId: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    departmentName: Sequelize.STRING
});

Department.hasMany(Employee, { foreignKey: 'department' });


module.exports.initialize = function () {
    var promise = new Promise((resolve, reject) => {
        sequelize.sync().then((Employee) => {
            resolve();
        }).then((Department) => {
            resolve();
        }).catch(() => {
            reject("unable to sync the database");
        });
    })

    return promise;
};

module.exports.getAllEmployees = function () {
    var promise = new Promise((resolve, reject) => {
        Employee.findAll().then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no results returned");
        });
    })

    return promise;
};

module.exports.getEmployeesByStatus = function (status) {
    var promise = new Promise((resolve, reject) => {
        Employee.findAll({
            where: {
                status: status
            }
        }).then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no results returned");
        });
    });

    return promise;
}

module.exports.getEmployeesByDepartment = function (department) {
    var promise = new Promise((resolve, reject) => {
        Employee.findAll({
            where: {
                department: department
            }
        }).then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no results returned");
        });
    });

    return promise;
}

module.exports.getEmployeesByManager = function (manager) {
    var promise = new Promise((resolve, reject) => {
        Employee.findAll({
            where: {
                employeeManagerNum: manager
            }
        }).then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no results returned");
        });
    });

    return promise;
}

module.exports.getEmployeeByNum = function (num) {
    var promise = new Promise((resolve, reject) => {
        Employee.findAll({
            where: {
                employeeNum: num
            }
        }).then((data) => {
            resolve(data[0]);
        }).catch((err) => {
            reject("no results returned");
        });
    });

    return promise;
}

module.exports.getManagers = function () {
    var promise = new Promise((resolve, reject) => {
        reject();
    })

    return promise;
};

module.exports.getDepartments = function () {
    var promise = new Promise((resolve, reject) => {
        Department.findAll().then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no results returned");
        });
    })

    return promise;
};

module.exports.addEmployee = function (employeeData) {
    var promise = new Promise((resolve, reject) => {
        employeeData.isManager = ((employeeData.isManager) ? true : false)

        for (const property in employeeData) {
            if (employeeData[property] == "") {
                employeeData[property] = null
            }
        }

        Employee.create({
            firstName: employeeData.firstName,
            lastName: employeeData.lastName,
            email: employeeData.email,
            SSN: employeeData.SSN,
            addressStreet: employeeData.addressStreet,
            addresCity: employeeData.addresCity,
            addressState: employeeData.addressState,
            addressPostal: employeeData.addressPosta,
            maritalStatus: employeeData.maritalStatus,
            isManager: employeeData.isManager,
            employeeManagerNum: employeeData.employeeManagerNum,
            status: employeeData.status,
            hireDate: employeeData.hireDate,
            department: employeeData.department
        }).then(() => {
            resolve("Employee creation success!");
        }).catch(() => {
            reject("unable to create employee");
        });
    })

    return promise;
}

module.exports.updateEmployee = function (employeeData) {
    var promise = new Promise((resolve, reject) => {
        employeeData.isManager = (employeeData.isManager) ? true : false;

        for (const prop in employeeData) {
            if (employeeData[prop] == "") {
                employeeData[prop] = null
            }
        }

        Employee.update({
            firstName: employeeData.firstName,
            lastName: employeeData.lastName,
            email: employeeData.email,
            SSN: employeeData.SSN,
            addressStreet: employeeData.addressStreet,
            addresCity: employeeData.addresCity,
            addressState: employeeData.addressState,
            addressPostal: employeeData.addressPosta,
            maritalStatus: employeeData.maritalStatus,
            isManager: employeeData.isManager,
            employeeManagerNum: employeeData.employeeManagerNum,
            status: employeeData.status,
            hireDate: employeeData.hireDate,
            department: employeeData.department
        }, {
                where: { employeeNum: employeeData.employeeNum }
            }).then(() => {
                resolve("Employee update success!");
            }).catch(() => {
                reject("unable to update Employee");
            });
    });

    return promise;
}

module.exports.addDepartment = function (departmentData) {
    var promise = new Promise((resolve, reject) => {
        for (const property in departmentData) {
            if (departmentData[property] == "") {
                departmentData[property] = null
            }
        }

        Department.create({
            departmentName: departmentData.departmentName
        }).then(() => {
            resolve("Department creation success!");
        }).catch(() => {
            reject("unable to create department");
        });
    });

    return promise;
}

module.exports.updateDepartment = function (departmentData) {
    var promise = new Promise((resolve, reject) => {
        for (const property in departmentData) {
            if (departmentData[property] == "") {
                departmentData[property] = null
            }
        }

        Department.update({
            departmentName: departmentData.departmentName
        }, {
                where: { departmentId: departmentData.departmentId }
            }).then(() => {
                resolve("Department update success!");
            }).catch(() => {
                reject("unable to update department");
            });
    });

    return promise;
}

module.exports.getDepartmentById = function (num) {
    var promise = new Promise((resolve, reject) => {
        Department.findAll({
            where: {
                departmentId: num
            }
        }).then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no results returned");
        });
    });

    return promise;
}

module.exports.deleteEmployeeByNum = function (num) {
    var promise = new Promise((resolve, reject) => {
        Employee.destroy({
            where: {
                employeeNum: num
            }
        }).then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no employees deleted");
        });
    });

    return promise;
}

module.exports.deleteDepartmentById = function (num) {
    var promise = new Promise((resolve, reject) => {
        Department.destroy({
            where: {
                departmentId: num
            }
        }).then((data) => {
            resolve(data);
        }).catch((err) => {
            reject("no departments deleted");
        });
    });

    return promise;
}